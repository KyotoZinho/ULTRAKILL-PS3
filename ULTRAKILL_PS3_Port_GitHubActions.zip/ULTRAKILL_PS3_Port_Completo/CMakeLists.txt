cmake_minimum_required(VERSION 3.10)
project(ULTRAKILL_PS3 CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Configuração para PS3 Cell Toolchain (PPU GCC / PSL1GHT)
if(DEFINED CMAKE_TOOLCHAIN_FILE)
    message(STATUS "Usando Toolchain PS3: ${CMAKE_TOOLCHAIN_FILE}")
endif()

include_directories(${CMAKE_CURRENT_SOURCE_DIR}/include)

file(GLOB SOURCES "src/*.cpp")
add_executable(ultrakill_ps3 ${SOURCES})
target_link_libraries(ultrakill_ps3 cellGcmSys psGL sysmodule io audio)
