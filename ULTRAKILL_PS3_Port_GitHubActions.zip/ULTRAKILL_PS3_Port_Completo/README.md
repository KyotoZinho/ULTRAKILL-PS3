# ULTRAKILL — Port Independente para PlayStation 3
**Coleção:** Machine Trilogy: Ports  
**Arquitetura:** C/C++ Própria (Sem Unity, Unreal ou Godot)  
**Hardware:** PlayStation 3 (Cell Broadband Engine + GPU RSX)

## Compilação (PSL1GHT / PS3 SDK)
```bash
mkdir build && cd build
cmake -DCMAKE_TOOLCHAIN_FILE=../toolchain-ps3.cmake ..
make
```
Empacote o ELF gerado em `.SELF` / `EBOOT.BIN` para execução no console.

## Compilar pelo celular (GitHub Actions)
1. Suba esta pasta para um repositório no GitHub (pode ser pelo app/site, no navegador).
2. Aba **Actions** → **Build PS3** → **Run workflow**.
3. Ao terminar, baixe o artefato `ultrakill-ps3` (ELF, SELF e PKG).
