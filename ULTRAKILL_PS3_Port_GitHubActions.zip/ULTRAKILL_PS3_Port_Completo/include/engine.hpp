#pragma once
#include <cstdint>
#include <vector>
#include <string>

namespace UKPS3 {

struct Vec3 { float x, y, z; };

enum class WeaponType {
    Revolver_Piercer, Revolver_Marksman, Revolver_Sharpshooter,
    Shotgun_CoreEject, Shotgun_PumpCharge, Shotgun_SawedOn,
    Nailgun_Attractor, Nailgun_Overheat, Nailgun_Screwdriver,
    Railcannon_Electric, Railcannon_Malicious, Railcannon_Screwdriver,
    Rocket_Freezeframe, Rocket_SRSCannon
};

enum class StyleRank { D, C, B, A, S, SS, SSS, ULTRAKILL };

class Player {
public:
    Vec3 position{0, 0, 0};
    Vec3 velocity{0, 0, 0};
    float health = 100.0f;
    float hardDamage = 0.0f;
    float stamina = 3.0f; // 3 barras de dash
    bool isGrounded = false;
    bool isSliding = false;
    WeaponType currentWeapon = WeaponType::Revolver_Piercer;

    void UpdateMovement(float dt, bool jump, bool dash, bool slide, Vec3 wishDir);
    void Jump();
    void Dash(Vec3 dir);
    void WallJump(Vec3 wallNormal);
    void AbsorbBlood(float amount);
    bool TryParry();
};

class CombatSystem {
public:
    float stylePoints = 0.0f;
    float multiplier = 1.0f;
    StyleRank GetRank() const;
    void AddStyle(float basePoints, const std::string& bonusName);
    void Update(float dt);
};

class RSXRenderer {
public:
    bool Init();
    void BeginFrame();
    void DrawMesh(uint32_t meshId, Vec3 pos, Vec3 rot);
    void DrawHUD(const Player& player, const CombatSystem& combat);
    void EndFrame();
};

class Engine {
public:
    bool Init();
    void Run();
    void Shutdown();
private:
    bool running = false;
    Player player;
    CombatSystem combat;
    RSXRenderer renderer;
};

} // namespace UKPS3
