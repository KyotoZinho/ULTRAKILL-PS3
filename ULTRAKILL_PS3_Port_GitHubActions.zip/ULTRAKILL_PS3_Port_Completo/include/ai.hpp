#pragma once
#include "engine.hpp"

namespace UKPS3 {

enum class AIState { Idle, Chase, Telegraph, Attack, Dodge, Stagger, Dead };

enum class BossID {
    CorpseOfKingMinos,
    FleshPrison,
    MinosPrime,
    Leviathan,
    SisypheanInsurrectionist,
    SisyphusPrime,
    Gabriel
};

class EnemyAI {
public:
    std::string name;
    float hp = 100.0f;
    float maxHp = 100.0f;
    Vec3 pos{0,0,0};
    AIState state = AIState::Idle;
    float stateTimer = 0.0f;
    bool isBoss = false;
    int phase = 1;

    virtual void Update(float dt, const Player& target);
    virtual void TakeDamage(float dmg, bool isParried);
};

class BossController : public EnemyAI {
public:
    BossID bossId;
    BossController(BossID id);
    void Update(float dt, const Player& target) override;
    void ExecuteSignatureCombo();
};

} // namespace UKPS3
