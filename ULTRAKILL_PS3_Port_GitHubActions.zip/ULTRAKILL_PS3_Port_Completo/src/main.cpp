#include "engine.hpp"
#include <iostream>

int main(int argc, char** argv) {
    UKPS3::Engine game;
    if (!game.Init()) {
        std::cerr << "[PS3] Falha ao inicializar subsistemas Cell/RSX.\n";
        return 1;
    }
    game.Run();
    game.Shutdown();
    return 0;
}
