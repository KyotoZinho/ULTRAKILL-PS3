#include "ai.hpp"
#include <cmath>

namespace UKPS3 {

void EnemyAI::Update(float dt, const Player& target) {
    if (state == AIState::Dead) return;
    stateTimer -= dt;

    float dx = target.position.x - pos.x;
    float dz = target.position.z - pos.z;
    float dist = std::sqrt(dx * dx + dz * dz);

    switch (state) {
        case AIState::Idle:
            if (dist < 40.0f) state = AIState::Chase;
            break;
        case AIState::Chase:
            if (dist < 6.0f) {
                state = AIState::Telegraph;
                stateTimer = 0.45f; // Telegraph visual/sonoro antes do ataque
            } else {
                pos.x += (dx / dist) * 8.0f * dt;
                pos.z += (dz / dist) * 8.0f * dt;
            }
            break;
        case AIState::Telegraph:
            if (stateTimer <= 0.0f) {
                state = AIState::Attack;
                stateTimer = 0.25f;
            }
            break;
        case AIState::Attack:
            if (stateTimer <= 0.0f) state = AIState::Chase;
            break;
        case AIState::Stagger:
            if (stateTimer <= 0.0f) state = AIState::Chase;
            break;
        default:
            break;
    }
}

void EnemyAI::TakeDamage(float dmg, bool isParried) {
    hp -= isParried ? (dmg * 2.5f) : dmg;
    if (isParried) {
        state = AIState::Stagger;
        stateTimer = 1.0f;
    }
    if (hp <= 0.0f) {
        hp = 0.0f;
        state = AIState::Dead;
    }
}

BossController::BossController(BossID id) : bossId(id) {
    isBoss = true;
    maxHp = 500.0f;
    hp = maxHp;
    switch (id) {
        case BossID::CorpseOfKingMinos: name = "Corpse of King Minos"; break;
        case BossID::FleshPrison: name = "Flesh Prison"; break;
        case BossID::MinosPrime: name = "Minos Prime"; break;
        case BossID::Leviathan: name = "Leviathan"; break;
        case BossID::SisypheanInsurrectionist: name = "Sisyphean Insurrectionist"; break;
        case BossID::SisyphusPrime: name = "Sisyphus Prime"; break;
        case BossID::Gabriel: name = "Gabriel"; break;
    }
}

void BossController::Update(float dt, const Player& target) {
    if (hp < maxHp * 0.5f && phase == 1) {
        phase = 2; // Segunda fase mais agressiva
    }
    EnemyAI::Update(dt, target);
}

void BossController::ExecuteSignatureCombo() {}

} // namespace UKPS3
