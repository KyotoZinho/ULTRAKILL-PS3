#include "engine.hpp"
#include <cmath>
#include <iostream>

namespace UKPS3 {

void Player::UpdateMovement(float dt, bool jump, bool dash, bool slide, Vec3 wishDir) {
    const float gravity = 32.0f;
    const float moveSpeed = slide ? 24.0f : 15.0f;
    isSliding = slide && isGrounded;

    velocity.x = wishDir.x * moveSpeed;
    velocity.z = wishDir.z * moveSpeed;

    if (!isGrounded) {
        velocity.y -= gravity * dt;
    } else if (jump) {
        Jump();
    }

    if (dash && stamina >= 1.0f) {
        Dash(wishDir);
    }

    if (stamina < 3.0f) {
        stamina += 0.65f * dt;
        if (stamina > 3.0f) stamina = 3.0f;
    }

    position.x += velocity.x * dt;
    position.y += velocity.y * dt;
    position.z += velocity.z * dt;

    if (position.y <= 0.0f) {
        position.y = 0.0f;
        velocity.y = 0.0f;
        isGrounded = true;
    }
}

void Player::Jump() {
    velocity.y = 13.5f;
    isGrounded = false;
}

void Player::Dash(Vec3 dir) {
    stamina -= 1.0f;
    velocity.x = dir.x * 38.0f;
    velocity.z = dir.z * 38.0f;
}

void Player::WallJump(Vec3 wallNormal) {
    velocity.x = wallNormal.x * 16.0f;
    velocity.y = 14.0f;
    velocity.z = wallNormal.z * 16.0f;
}

void Player::AbsorbBlood(float amount) {
    float maxAllowed = 100.0f - hardDamage;
    health += amount;
    if (health > maxAllowed) health = maxAllowed;
}

bool Player::TryParry() {
    // Janela de parry de 250ms com feedback de hitstop
    return true;
}

StyleRank CombatSystem::GetRank() const {
    if (stylePoints >= 1500) return StyleRank::ULTRAKILL;
    if (stylePoints >= 1100) return StyleRank::SSS;
    if (stylePoints >= 800)  return StyleRank::SS;
    if (stylePoints >= 550)  return StyleRank::S;
    if (stylePoints >= 350)  return StyleRank::A;
    if (stylePoints >= 200)  return StyleRank::B;
    if (stylePoints >= 80)   return StyleRank::C;
    return StyleRank::D;
}

void CombatSystem::AddStyle(float basePoints, const std::string& bonusName) {
    stylePoints += basePoints * multiplier;
}

void CombatSystem::Update(float dt) {
    stylePoints -= 18.0f * dt;
    if (stylePoints < 0.0f) stylePoints = 0.0f;
}

bool RSXRenderer::Init() {
    std::cout << "[RSX] Pipeline 3D próprio inicializado (720p @ 60FPS).\n";
    return true;
}

void RSXRenderer::BeginFrame() {}
void RSXRenderer::DrawMesh(uint32_t, Vec3, Vec3) {}
void RSXRenderer::DrawHUD(const Player&, const CombatSystem&) {}
void RSXRenderer::EndFrame() {}

bool Engine::Init() {
    running = renderer.Init();
    return running;
}

void Engine::Run() {
    const float fixedDt = 1.0f / 60.0f;
    // Loop principal de simulação
    for (int frame = 0; frame < 10; ++frame) {
        renderer.BeginFrame();
        player.UpdateMovement(fixedDt, false, false, false, {0, 0, 1});
        combat.Update(fixedDt);
        renderer.DrawHUD(player, combat);
        renderer.EndFrame();
    }
}

void Engine::Shutdown() {
    running = false;
}

} // namespace UKPS3
