#include "engine.hpp"
#include "ai.hpp"
#include <cassert>

int main() {
    UKPS3::Player p;
    p.Jump();
    assert(!p.isGrounded);
    p.AbsorbBlood(25.0f);
    assert(p.health == 100.0f);

    UKPS3::CombatSystem cs;
    cs.AddStyle(1600.0f, "ULTRARICOSHOT");
    assert(cs.GetRank() == UKPS3::StyleRank::ULTRAKILL);

    UKPS3::BossController minos(UKPS3::BossID::MinosPrime);
    minos.TakeDamage(300.0f, true);
    assert(minos.hp < 0.0f || minos.state == UKPS3::AIState::Dead);
    return 0;
}
